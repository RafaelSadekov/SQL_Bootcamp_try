SELECT name, age
FROM person
    WHERE address='Kazan' AND gender='female'
ORDER BY name