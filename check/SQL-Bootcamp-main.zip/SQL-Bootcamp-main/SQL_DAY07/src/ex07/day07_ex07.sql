SELECT ROUND(AVG(rating), 4) AS global_rating
FROM pizzeria;
